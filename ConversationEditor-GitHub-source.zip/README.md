# Conversation Editor

[简体中文](README.zh-CN.md)

A Windows desktop editor for local Antigravity CLI (AGY CLI), Antigravity App, Claude Code, and Codex conversations. Edit both user and assistant text, refresh the session list, and open existing or new sessions in their native clients.

## Download and use

1. Under this repository's **Releases**, download **ConversationEditor-windows-x64.exe**. Double-click it on Windows 10 or 11 (x64). The build bundles Python and Tk. It is unsigned.
2. Choose one of the four clients, then pick a conversation and a message. Use **Save** or **Ctrl+S**, and **Refresh** or **F5**.
3. Use **Open** to return to a saved session or **New session** to open a new composer or terminal. The editor never submits a prompt.

Install and sign in to whichever native clients you want to use. If your installation or profile is in a custom location, select the client first and open **Settings**. A blank field uses automatic detection. Select the client profile folder itself, for example the folder containing Claude Code's `projects` directory. AGY directory overrides change where the editor reads and writes. The native AGY client still opens sessions from its own profile.

| Client | Save behavior | Open behavior |
| --- | --- | --- |
| Antigravity CLI | Exit the client first. Supported local SQLite transcripts are updated in place with a backup. | Launches the installed CLI and resumes by ID. |
| Antigravity App | Exit the app, including its tray icon, before saving. Supported local SQLite transcripts are updated in place with a backup. | Opens the conversation picker and copies the session title for pasting. |
| Claude Code | Exit Claude Code before saving. Local JSONL transcripts are updated in place with a backup. | Resumes by ID using the selected profile folder. |
| Codex | Creates a new native Codex conversation from the edited user and assistant text. The original conversation is preserved. | Opens Codex Desktop when its local link handler is available, or uses the CLI. |

Conversation formats can change across client versions. The editor supports local, readable histories. Cloud-only chats, unsupported historical Antigravity formats, and Codex chats with missing history segments may be unavailable. A Codex text copy omits tool events, attachments, hidden messages, and existing summaries. Large copies are still subject to the model's context window.

## Data and backups

The editor does not send transcripts to a service or collect telemetry. It uses the locally installed clients for native session actions. Native clients retain their own authentication, syncing, and model behavior.

The tool stores settings and backups under `%LOCALAPPDATA%\ConversationEditor`. Backups contain conversation data. To restore an in-place edit, close the native client, keep a copy of the current transcript, and replace the original transcript with the corresponding backup using the original filename. The editor's **Backups** button opens the backup folder.

To verify the downloaded executable, compare this result with the matching line in `SHA256SUMS.txt` from the same release.

```powershell
Get-FileHash .\ConversationEditor-windows-x64.exe -Algorithm SHA256
```

## Build locally

Use Windows x64 and 64-bit Python 3.12 with Tcl/Tk.

```powershell
py -3.12 editor.py
py -3.12 -m unittest discover -s tests -v
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe build_release.py
```

The build writes the executable, its SHA-256 checksum, and bundled component notices to `dist/`.

## Publish a release

Put the contents of this source directory at the root of a GitHub repository, including the hidden `.github` directory. Enable GitHub Actions for that repository. The Windows workflow runs synthetic transcript tests, builds the executable, runs a startup smoke test, and attaches the build as an Actions artifact. Pushing a version tag such as `v1.0.0` runs the same checks and publishes the successful build to **Releases**.

```powershell
git tag v1.0.0
git push origin v1.0.0
```

This project is independent of the four clients it supports. Source code is provided under the MIT License.
