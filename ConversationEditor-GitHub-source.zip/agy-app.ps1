param([string] $App, [ValidateSet('new', 'picker')] [string] $Action)
$ErrorActionPreference = 'Stop'
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class ActiveWindow {
    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr window, out uint processId);
}
'@
Start-Process -FilePath $App
$keyboard = New-Object -ComObject WScript.Shell
$until = (Get-Date).AddSeconds(12)
do {
    Start-Sleep -Milliseconds 200
    $apps = Get-Process -Name ([IO.Path]::GetFileNameWithoutExtension($App)) -ErrorAction SilentlyContinue |
        Where-Object { $_.MainWindowHandle -ne 0 -and $_.Path -eq $App }
    foreach ($client in $apps) {
        if ($keyboard.AppActivate($client.Id)) {
            Start-Sleep -Milliseconds 150
            [uint32] $foregroundId = 0
            [void] [ActiveWindow]::GetWindowThreadProcessId(
                [ActiveWindow]::GetForegroundWindow(), [ref] $foregroundId)
            if ($foregroundId -eq $client.Id) {
                if ($Action -eq 'new') { $keyboard.SendKeys('^n') }
                else { $keyboard.SendKeys('^k') }
                exit 0
            }
        }
    }
} while ((Get-Date) -lt $until)
throw 'Antigravity App window could not be activated.'
