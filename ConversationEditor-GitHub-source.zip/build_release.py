"""Build a Windows x64 executable and its SHA-256 checksum."""
import argparse
import hashlib
from importlib.metadata import distribution
import os
from pathlib import Path
import platform
import struct
import sys

import PyInstaller.__main__


def write_notices(destination):
    python = Path(sys.base_prefix)
    pyinstaller = distribution("pyinstaller")
    pyinstaller_notice = next(
        pyinstaller.locate_file(path)
        for path in pyinstaller.files
        if path.name == "COPYING.txt" and path.parent.name == "licenses"
    )
    components = [
        ("CPython and bundled components", python / "LICENSE.txt"),
        ("Tcl/Tk", python / "tcl/tk8.6/license.terms"),
        ("PyInstaller bootloader", pyinstaller_notice),
    ]
    sections = [
        f"{title}\n{'=' * len(title)}\n{path.read_text(encoding='utf-8')}"
        for title, path in components
    ]
    sections.append("SQLite\n======\nSQLite is dedicated to the public domain. https://sqlite.org/copyright.html\n")
    destination.write_text("\n\n".join(sections), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("dist"))
    parser.add_argument("--work", type=Path, default=Path("build"))
    args = parser.parse_args()
    if os.name != "nt" or struct.calcsize("P") != 8 or platform.machine().lower() not in {"amd64", "x86_64"}:
        parser.error("Build the Windows x64 release on Windows with 64-bit Python.")
    base = Path(__file__).resolve().parent
    output = args.output.resolve()
    work = args.work.resolve()
    work.mkdir(parents=True, exist_ok=True)
    name = "ConversationEditor-windows-x64"
    notices = work / "THIRD-PARTY-NOTICES.txt"
    write_notices(notices)
    # Use only Windows and the selected Python installation when resolving DLLs.
    windows = Path(os.environ["SystemRoot"])
    os.environ["PATH"] = os.pathsep.join(map(str, (windows / "System32", windows, Path(sys.base_prefix))))
    os.environ["PYINSTALLER_CONFIG_DIR"] = str(work / "cache")
    PyInstaller.__main__.run([
        "--noconfirm", "--onefile", "--windowed", "--noupx",
        "--name", name, "--distpath", str(output), "--workpath", str(work / "pyinstaller"),
        "--specpath", str(work),
        "--add-data", f"{base / 'agy-app.ps1'}:.",
        "--add-data", f"{base / 'launch-shim.ps1'}:.",
        "--add-data", f"{base / 'LICENSE'}:.",
        "--add-data", f"{notices}:.",
        str(base / "editor.py"),
    ])
    executable = output / f"{name}.exe"
    (output / notices.name).write_bytes(notices.read_bytes())
    with executable.open("rb") as source:
        digest = hashlib.file_digest(source, "sha256").hexdigest()
    (output / "SHA256SUMS.txt").write_text(f"{digest}  {executable.name}\n", encoding="ascii")


if __name__ == "__main__":
    main()
