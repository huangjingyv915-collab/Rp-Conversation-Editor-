"""Windows conversation editor."""
import os
import queue
from pathlib import Path
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText

import native
import storage
import settings
from language import tr

PLATFORMS = settings.PLATFORMS
ROLE = {"user": "用户问题", "assistant": "模型回答"}
HINT = {
    "AGY CLI": "保存前退出 AGY CLI。保存后点「打开」，重新载入这条会话。",
    "AGY App": "保存前退出 Antigravity（包括托盘）。点「打开」后，从会话搜索中重新打开。",
    "Claude Code": "保存前退出 Claude Code。保存后点「打开」，重新载入这条会话。",
    "Codex": "保存会创建包含用户问题和模型回答的 Codex 文本副本。点「打开」可继续。",
}


class Editor:
    def __init__(self, root):
        self.root = root
        self.platform = tk.StringVar(value=PLATFORMS[0])
        self.search = tk.StringVar()
        self.hint = tk.StringVar()
        self.status = tk.StringVar()
        self.current = None
        self.snapshot = None
        self.active = None
        self.sessions = []
        self.visible = []
        self.messages = []
        self.changes = {}
        self.busy = False
        root.title(tr("会话编辑器"))
        root.geometry("1160x720")
        root.minsize(880, 530)
        style = ttk.Style(root)
        style.configure("Treeview", rowheight=28)
        style.configure("Header.TLabel", font=("Segoe UI", 13, "bold"))
        root.option_add("*Font", ("Segoe UI", 10))

        header = ttk.Frame(root, padding=(16, 14, 16, 8))
        header.pack(fill="x")
        ttk.Label(header, text=tr("会话编辑器"), style="Header.TLabel").pack(side="left", padx=(0, 16))
        self.platform_select = ttk.Combobox(header, textvariable=self.platform, values=PLATFORMS, state="readonly", width=14)
        self.platform_select.pack(side="left", padx=(0, 10))
        self.platform_select.bind("<<ComboboxSelected>>", self.switch)
        self.buttons = {}
        for label, command in (
            ("刷新", self.refresh), ("打开", self.open_selected), ("新会话", self.open_new), ("保存", self.save)
        ):
            button = ttk.Button(header, text=tr(label), command=command)
            button.pack(side="left", padx=(0, 6))
            self.buttons[label] = button
        ttk.Button(header, text=tr("备份文件夹"), command=self.open_backups).pack(side="right")
        self.settings_button = ttk.Button(header, text=tr("设置"), command=self.open_settings)
        self.settings_button.pack(side="right", padx=(0, 6))
        ttk.Label(root, textvariable=self.hint, padding=(16, 0, 16, 10)).pack(fill="x")

        pane = ttk.Panedwindow(root, orient="horizontal")
        pane.pack(fill="both", expand=True, padx=16)
        left = ttk.Frame(pane, padding=(0, 0, 10, 0), width=330)
        right = ttk.Frame(pane)
        pane.add(left, weight=1)
        pane.add(right, weight=3)
        search_row = ttk.Frame(left)
        search_row.pack(fill="x", pady=(0, 7))
        ttk.Label(search_row, text=tr("搜索会话")).pack(side="left", padx=(0, 7))
        ttk.Entry(search_row, textvariable=self.search).pack(fill="x", expand=True)
        self.search.trace_add("write", lambda *_: self.populate_sessions())
        self.session_tree = self.tree(left, "会话")
        self.session_tree.bind("<<TreeviewSelect>>", self.pick_session)

        message_pane = ttk.Panedwindow(right, orient="vertical")
        message_pane.pack(fill="both", expand=True)
        transcript = ttk.Frame(message_pane, height=220)
        body = ttk.Frame(message_pane, padding=(0, 8, 0, 0))
        message_pane.add(transcript, weight=1)
        message_pane.add(body, weight=2)
        self.message_tree = self.tree(transcript, "消息")
        self.message_tree.bind("<<TreeviewSelect>>", self.pick_message)
        self.label = ttk.Label(body, text=tr("正文"))
        self.label.pack(anchor="w", pady=(0, 5))
        self.editor = ScrolledText(body, wrap="word", undo=True, font=("Segoe UI", 11), padx=10, pady=8)
        self.editor.pack(fill="both", expand=True)
        self.editor.bind("<<Modified>>", self.edited)
        ttk.Label(root, textvariable=self.status, padding=(16, 8, 16, 10)).pack(fill="x")
        root.bind("<Control-s>", lambda _: self.save())
        root.bind("<F5>", lambda _: self.refresh())
        root.protocol("WM_DELETE_WINDOW", self.close)
        self.refresh()

    def tree(self, parent, label):
        area = ttk.Frame(parent)
        area.pack(fill="both", expand=True)
        tree = ttk.Treeview(area, columns=("text",), show="headings", selectmode="browse")
        tree.heading("text", text=tr(label), anchor="w")
        tree.column("text", width=220, minwidth=160)
        scrollbar = ttk.Scrollbar(area, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        tree.pack(side="left", expand=True, fill="both")
        return tree

    def run(self, label, task, done, on_error=None):
        if self.busy:
            return
        self.busy = True
        self.status.set(tr(label))
        self.update_controls()
        output = queue.Queue()

        def work():
            try:
                output.put((True, task()))
            except Exception as error:
                output.put((False, error))

        def poll():
            try:
                success, result = output.get_nowait()
            except queue.Empty:
                self.root.after(60, poll)
                return
            self.busy = False
            if success:
                done(result)
            else:
                if on_error:
                    on_error()
                self.status.set(str(result))
                messagebox.showerror(tr("操作失败"), str(result), parent=self.root)
            self.update_controls()

        threading.Thread(target=work, daemon=True).start()
        self.root.after(60, poll)

    def clear_editor(self):
        self.current = self.snapshot = self.active = None
        self.messages = []
        self.changes.clear()
        self.message_tree.delete(*self.message_tree.get_children())
        self.show_message(None)

    def update_controls(self):
        self.platform_select.configure(state="disabled" if self.busy else "readonly")
        self.settings_button.configure(state="disabled" if self.busy else "normal")
        for name, available in (
            ("刷新", True), ("打开", self.current is not None),
            ("新会话", True), ("保存", bool(self.changes)),
        ):
            self.buttons[name].configure(state="normal" if available and not self.busy else "disabled")
        self.editor.configure(state="normal" if self.active is not None and not self.busy else "disabled")

    def discard(self):
        return not self.changes or messagebox.askyesno(
            tr("有修改尚未保存"), tr("放弃这次修改？"), parent=self.root,
        )

    def switch(self, _event):
        if not self.discard():
            self.platform.set(self.loaded_platform)
            return
        self.search.set("")
        self.refresh(force=True)

    def refresh(self, *_args, force=False, target=None):
        if self.busy or (not force and not self.discard()):
            return
        platform = self.platform.get()
        if self.current and self.current.platform == platform:
            target = target or self.current.id
        self.clear_editor()
        self.loaded_platform = platform
        self.sessions = []
        self.populate_sessions()
        self.hint.set(tr(HINT[platform]))

        def loaded(sessions):
            self.sessions = sessions
            self.populate_sessions()
            if not sessions:
                self.status.set(tr("这个工具还没有可编辑的本地会话。可以先打开一个新会话。"))
            elif self.visible:
                found = next((i for i, s in enumerate(self.visible) if s.id == target), 0)
                self.select_row(found)
                self.pick_session()
            else:
                self.status.set(tr("没有匹配的会话。"))

        self.run("正在读取会话列表…", lambda: list(storage.find_sessions(platform)), loaded)

    def populate_sessions(self):
        query = self.search.get().strip().casefold()
        self.visible = [s for s in self.sessions if query in f"{s.title} {s.id} {s.cwd}".casefold()]
        self.session_tree.delete(*self.session_tree.get_children())
        for index, session in enumerate(self.visible):
            self.session_tree.insert("", "end", iid=str(index), values=(session.title,))
        if self.current in self.visible:
            self.select_row(self.visible.index(self.current))

    def select_row(self, index):
        self.session_tree.selection_set(str(index))
        self.session_tree.see(str(index))

    def pick_session(self, _event=None):
        selected = self.session_tree.selection()
        if self.busy or not selected:
            return
        session = self.visible[int(selected[0])]
        if session == self.current:
            return
        if not self.discard():
            if self.current in self.visible:
                self.select_row(self.visible.index(self.current))
            return
        self.clear_editor()

        def loaded(result):
            self.current = session
            self.snapshot, self.messages = result
            for index, message in enumerate(self.messages):
                prefix = tr(ROLE[message.role])
                summary = " ".join(message.text.split())[:130]
                self.message_tree.insert("", "end", iid=str(index), values=(f"{prefix}   {summary}",))
            if self.messages:
                last = str(len(self.messages) - 1)
                self.message_tree.selection_set(last)
                self.message_tree.see(last)
                self.pick_message()
                self.status.set(tr("{count} 段可编辑的文字", count=len(self.messages)))
            else:
                self.status.set(tr("这个会话还没有可编辑的用户问题或模型回答。"))

        self.run("正在读取消息…", lambda: storage.load(session), loaded,
                 on_error=lambda: self.session_tree.selection_remove(*self.session_tree.selection()))

    def pick_message(self, _event=None):
        selected = self.message_tree.selection()
        if self.busy or not selected:
            return
        self.show_message(self.messages[int(selected[0])])
        self.update_controls()

    def show_message(self, message):
        self.active = message
        self.label.configure(text=tr(ROLE[message.role]) if message else tr("正文"))
        self.editor.configure(state="normal")
        self.editor.delete("1.0", "end")
        if message:
            self.editor.insert("1.0", self.changes.get(message.key, message.text))
        self.editor.edit_reset()
        self.editor.edit_modified(False)
        self.editor.configure(state="normal" if message else "disabled")

    def edited(self, _event):
        if not self.editor.edit_modified():
            return
        self.editor.edit_modified(False)
        if self.active and not self.busy:
            text = self.editor.get("1.0", "end-1c")
            if text == self.active.text:
                self.changes.pop(self.active.key, None)
            else:
                self.changes[self.active.key] = text
            count = len(self.changes)
            self.status.set(tr("{count} 段修改尚未保存", count=count) if count else tr("{count} 段可编辑的文字", count=len(self.messages)))
            self.update_controls()

    def save(self):
        if self.busy or not self.changes or self.current is None:
            return
        if any(not value.strip() for value in self.changes.values()):
            messagebox.showerror(tr("无法保存"), tr("请为每条修改后的消息保留正文。"), parent=self.root)
            return
        session, revision, changes = self.current, self.snapshot, dict(self.changes)
        save = {
            "AGY CLI": storage.save_agy,
            "AGY App": storage.save_agy,
            "Claude Code": storage.save_claude,
            "Codex": native.save_codex,
        }[session.platform]

        def saved(ident):
            self.changes.clear()
            if session.platform == "Codex":
                self.search.set("")
                messagebox.showinfo(tr("已保存"), tr("已创建编辑副本。刷新后会选中该副本。"), parent=self.root)
            else:
                messagebox.showinfo(tr("已保存"), tr("已更新这条本地会话并保留备份。"), parent=self.root)
            self.refresh(force=True, target=ident)

        self.run("正在保存…", lambda: save(session, revision, changes), saved)

    def open_selected(self):
        if self.busy or not self.current:
            return
        session = self.current
        if session.platform == "AGY App":
            self.root.clipboard_clear()
            self.root.clipboard_append(session.title)
            self.root.update_idletasks()
        self.run("正在打开…", lambda: native.open_native(session.platform, session),
                 lambda _: self.status.set(tr("已复制会话名称。可在 Antigravity 搜索框粘贴。"
                                              if session.platform == "AGY App" else "已请求客户端打开会话。")))

    def open_new(self):
        if self.busy:
            return
        platform, session = self.platform.get(), self.current
        self.run("正在打开新会话…", lambda: native.open_native(platform, session, new=True),
                 lambda _: self.status.set(tr("已请求客户端打开新会话。")))

    def open_settings(self):
        if self.busy or not self.discard():
            return
        platform = self.platform.get()
        try:
            stored = settings.read().get(platform, {})
            detected = settings.data_home(platform)
        except (OSError, ValueError) as error:
            messagebox.showerror(tr("操作失败"), str(error), parent=self.root)
            return
        window = tk.Toplevel(self.root)
        window.title(f"{tr('设置')} · {platform}")
        window.transient(self.root)
        window.grab_set()
        form = ttk.Frame(window, padding=16)
        form.pack(fill="both", expand=True)
        form.columnconfigure(1, weight=1)
        data = tk.StringVar(value=stored.get("data", ""))
        binary = tk.StringVar(value=stored.get("executable", ""))

        def browse(variable, picker):
            selected = picker(parent=window)
            if selected:
                variable.set(selected)

        for row, (label, variable, picker) in enumerate((
            ("数据目录", data, filedialog.askdirectory),
            ("客户端程序", binary, filedialog.askopenfilename),
        )):
            ttk.Label(form, text=tr(label)).grid(row=row, column=0, sticky="w", padx=(0, 8), pady=5)
            ttk.Entry(form, textvariable=variable, width=53).grid(row=row, column=1, sticky="ew", pady=5)
            ttk.Button(form, text=tr("选择…"), command=lambda v=variable, p=picker: browse(v, p)).grid(
                row=row, column=2, padx=(8, 0),
            )
        ttk.Label(form, text=tr("留空可自动查找。AGY 的自定义数据目录仅供编辑器读写。"),
                  wraplength=490).grid(row=2, column=0, columnspan=3, sticky="w", pady=(8, 2))
        ttk.Label(form, text=tr("当前数据目录：{path}", path=detected), wraplength=490).grid(
            row=3, column=0, columnspan=3, sticky="w", pady=(0, 8),
        )

        def apply():
            try:
                settings.save(platform, data.get(), binary.get())
            except (OSError, ValueError) as error:
                messagebox.showerror(tr("无法保存"), str(error), parent=window)
                return
            window.destroy()
            self.refresh(force=True)

        buttons = ttk.Frame(form)
        buttons.grid(row=4, column=0, columnspan=3, sticky="e")
        ttk.Button(buttons, text=tr("取消"), command=window.destroy).pack(side="left", padx=(0, 8))
        ttk.Button(buttons, text=tr("保存"), command=apply).pack(side="left")

    def open_backups(self):
        storage.BACKUPS.mkdir(parents=True, exist_ok=True)
        os.startfile(storage.BACKUPS)

    def close(self):
        if not self.busy and self.discard():
            self.root.destroy()


def main():
    root = tk.Tk()
    if len(sys.argv) == 3 and sys.argv[1] == "--smoke-test":
        root.withdraw()
        for name in ("agy-app.ps1", "launch-shim.ps1"):
            assert Path(__file__).with_name(name).is_file()
        root.update_idletasks()
        Path(sys.argv[2]).write_text("OK", encoding="utf-8")
        root.destroy()
        return
    Editor(root)
    root.mainloop()


if __name__ == "__main__":
    main()
