"""UI translations selected from the Windows display language."""
import ctypes

CHINESE = (ctypes.windll.kernel32.GetUserDefaultUILanguage() & 0x3FF) == 4
EN = {
    "会话编辑器": "Conversation Editor",
    "用户问题": "User message",
    "模型回答": "Assistant response",
    "刷新": "Refresh",
    "打开": "Open",
    "新会话": "New session",
    "保存": "Save",
    "备份文件夹": "Backups",
    "搜索会话": "Search sessions",
    "会话": "Sessions",
    "消息": "Messages",
    "正文": "Message",
    "设置": "Settings",
    "选择…": "Browse…",
    "取消": "Cancel",
    "数据目录": "Data directory",
    "客户端程序": "Client executable",
    "留空可自动查找。AGY 的自定义数据目录仅供编辑器读写。":
        "Leave fields blank for automatic detection. AGY data overrides apply only to the editor.",
    "当前数据目录：{path}": "Current data directory: {path}",
    "保存前退出 AGY CLI。保存后点「打开」，重新载入这条会话。":
        "Exit AGY CLI before saving. Open the session again to load the changes.",
    "保存前退出 Antigravity（包括托盘）。点「打开」后，从会话搜索中重新打开。":
        "Exit Antigravity, including its tray icon, before saving. Use the conversation picker to reopen the session.",
    "保存前退出 Claude Code。保存后点「打开」，重新载入这条会话。":
        "Exit Claude Code before saving. Open the session again to load the changes.",
    "保存会创建包含用户问题和模型回答的 Codex 文本副本。点「打开」可继续。":
        "Saving creates a Codex copy with the edited user and assistant text. Open the copy to continue.",
    "操作失败": "Operation failed",
    "有修改尚未保存": "Unsaved changes",
    "放弃这次修改？": "Discard your unsaved changes?",
    "这个工具还没有可编辑的本地会话。可以先打开一个新会话。":
        "No editable local sessions found. Start a session or check the data directory in Settings.",
    "没有匹配的会话。": "No matching sessions.",
    "正在读取会话列表…": "Loading sessions…",
    "{count} 段可编辑的文字": "{count} editable text blocks",
    "这个会话还没有可编辑的用户问题或模型回答。": "No editable user or assistant text in this session.",
    "正在读取消息…": "Loading messages…",
    "{count} 段修改尚未保存": "{count} unsaved text edits",
    "无法保存": "Unable to save",
    "请为每条修改后的消息保留正文。": "Edited messages must contain text.",
    "已保存": "Saved",
    "已创建编辑副本。刷新后会选中该副本。": "Created an edited copy. It will be selected after refreshing.",
    "已更新这条本地会话并保留备份。": "Saved this local session and created a backup.",
    "正在保存…": "Saving…",
    "正在打开…": "Opening…",
    "已复制会话名称。可在 Antigravity 搜索框粘贴。":
        "Session name copied. Paste it into the Antigravity picker.",
    "已请求客户端打开会话。": "Requested the client to open the session.",
    "正在打开新会话…": "Opening a new session…",
    "已请求客户端打开新会话。": "Requested a new session in the client.",
    "会话在编辑期间发生了变化。请刷新并重新编辑。": "The session changed during editing. Refresh and try again.",
    "会话在保存期间发生了变化，请刷新。": "The session changed while saving. Refresh and try again.",
    "请完全退出 {platform}（AGY App 也要退出系统托盘），再保存并重新打开会话。":
        "Fully exit {platform}, including its tray icon if present, then save and reopen the session.",
    "找不到 Codex 会话的上一段历史，无法完整载入。": "A required earlier Codex history segment could not be located.",
    "Codex 会话的历史文件存在循环引用。": "The Codex history contains a circular reference.",
    "无效的 Antigravity 消息编码。": "Invalid Antigravity message encoding.",
    "无效的 Antigravity 字段。": "Invalid Antigravity message field.",
    "Antigravity 消息不完整。": "Incomplete Antigravity message.",
    "此 Antigravity 消息使用了不同的编码。": "Unsupported Antigravity message encoding.",
    "Codex 等待超时（{method}）。": "Codex timed out ({method}).",
    "Codex 提前关闭（{method}）。": "Codex closed unexpectedly ({method}).",
    " · 已编辑": " · Edited",
}


def tr(message, **fields):
    return (message if CHINESE else EN.get(message, message)).format(**fields)
