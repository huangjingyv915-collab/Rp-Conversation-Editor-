$launcher, $arguments = $args
[Console]::InputEncoding = [Text.Encoding]::UTF8
[Console]::OutputEncoding = [Text.Encoding]::UTF8
& $launcher @arguments
exit $LASTEXITCODE
