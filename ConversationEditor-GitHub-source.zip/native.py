"""Open sessions with the installed Windows clients."""
from datetime import datetime
from functools import cache
import json
import os
from pathlib import Path
import shutil
import queue
import subprocess
import tempfile
import threading
from urllib.parse import urlencode
from uuid import UUID, uuid4

import settings
import storage
from language import tr

LOCAL = settings.LOCAL
ROAMING = settings.ROAMING
POWERSHELL = Path(os.environ["SystemRoot"]) / "System32/WindowsPowerShell/v1.0/powershell.exe"


@cache
def codex_package():
    result = subprocess.run(
        [str(POWERSHELL), "-NoProfile", "-Command",
         "[Console]::OutputEncoding = [Text.Encoding]::UTF8; "
         "(Get-AppxPackage -Name OpenAI.Codex | Select-Object -First 1).InstallLocation"],
        capture_output=True, encoding="utf-8", timeout=10, creationflags=subprocess.CREATE_NO_WINDOW,
    )
    location = result.stdout.strip()
    return Path(location) if location else None


def executable(platform):
    configured = settings.get(platform, "executable")
    if configured:
        if configured.is_file():
            return configured
        raise FileNotFoundError("The configured executable no longer exists. Check Settings.")

    bin_dir = settings.HOME / ".local/bin"
    program_files = Path(os.environ.get("ProgramFiles") or "C:/Program Files")
    npm = ROAMING / "npm"
    if platform == "AGY CLI":
        candidates = [LOCAL / "agy/bin/agy.exe", bin_dir / "agy.exe"]
        names = ("agy.exe", "agy.cmd")
    elif platform == "AGY App":
        candidates = [LOCAL / "Programs/antigravity/Antigravity.exe",
                      program_files / "Antigravity/Antigravity.exe"]
        names = ("Antigravity.exe",)
    elif platform == "Claude Code":
        candidates = [bin_dir / "claude.exe",
                      npm / "node_modules/@anthropic-ai/claude-code/bin/claude.exe"]
        names = ("claude.exe", "claude.cmd")
    else:
        package = codex_package()
        modules = npm / "node_modules/@openai/codex/node_modules/@openai"
        candidates = ([package / "app/resources/codex.exe"] if package else []) + [
            bin_dir / "codex.exe", *modules.glob("codex-win32-*/vendor/*/bin/codex.exe"),
        ]
        names = ("codex.exe", "codex.cmd")

    for binary in candidates:
        if binary.is_file():
            return binary
    for name in names:
        entry = shutil.which(name)
        if entry:
            return Path(entry)
    raise FileNotFoundError(f"{platform} was not found. Install it or choose its executable in Settings.")


def command_line(binary, args):
    if binary.suffix.lower() == ".exe":
        return [str(binary), *args]
    # A PowerShell script passes each argument as data to installed npm shims.
    return [str(POWERSHELL), "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
            str(Path(__file__).with_name("launch-shim.ps1")), str(binary), *args]


def codex_bin():
    return executable("Codex")


class CodexClient:
    def __init__(self, cwd):
        self.cwd = cwd
        self.pending = queue.Queue()
        self.index = 0

    def __enter__(self):
        self.proc = subprocess.Popen(
            command_line(codex_bin(), ["app-server", "--listen", "stdio://"]),
            cwd=self.cwd, env=os.environ | {"CODEX_HOME": str(settings.codex_home())}, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            encoding="utf-8", creationflags=subprocess.CREATE_NO_WINDOW,
        )
        threading.Thread(target=self.receive, daemon=True).start()
        try:
            self.call("initialize", {
                "clientInfo": {"name": "conversation_editor", "version": "1.0.0"},
                "capabilities": {"experimentalApi": True},
            })
            self.send({"method": "initialized"})
        except Exception:
            self.__exit__()
            raise
        return self

    def __exit__(self, *exc):
        self.proc.stdin.close()
        try:
            self.proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            self.proc.terminate()
            self.proc.wait(timeout=3)
        self.proc.stdout.close()

    def receive(self):
        for line in self.proc.stdout:
            try:
                message = json.loads(line)
            except json.JSONDecodeError:
                continue
            if "id" in message and ("result" in message or "error" in message):
                self.pending.put(message)
        self.pending.put(None)

    def send(self, message):
        self.proc.stdin.write(json.dumps(message) + "\n")
        self.proc.stdin.flush()

    def call(self, method, params):
        self.index += 1
        self.send({"id": self.index, "method": method, "params": params})
        try:
            response = self.pending.get(timeout=30)
        except queue.Empty as exc:
            raise RuntimeError(tr("Codex 等待超时（{method}）。", method=method)) from exc
        if response is None:
            raise RuntimeError(tr("Codex 提前关闭（{method}）。", method=method))
        if "error" in response:
            raise RuntimeError(response["error"]["message"])
        return response["result"]


def codex_seed(session, ident, messages, changes):
    with session.path.open("rb") as source:
        meta = json.loads(source.readline())
    payload = meta["payload"]
    for name in ("history_base", "forked_from_id", "forked_from_ordinal_exclusive", "attached_thread"):
        payload.pop(name, None)
    payload.update(id=ident, session_id=ident, history_mode="legacy")
    timestamp = meta["timestamp"]
    yield {"timestamp": timestamp, "type": "session_meta", "payload": payload}

    def event(kind, **fields):
        return {"timestamp": timestamp, "type": "event_msg", "payload": {"type": kind, **fields}}

    turn = None
    last_answer = None
    for message in messages:
        role = message.role
        if turn is None or (role == "user" and last_answer is not None):
            if turn is not None:
                yield event("task_complete", turn_id=turn, last_agent_message=last_answer)
            turn = str(uuid4())
            last_answer = None
            yield event("task_started", turn_id=turn)
        text = changes.get(message.key, message.text)
        if role == "assistant":
            last_answer = text
            yield event("agent_message", message=text, phase="final_answer")
        else:
            yield event("user_message", message=text, images=[], local_images=[], text_elements=[])
        yield {
            "timestamp": timestamp,
            "type": "response_item",
            "payload": {
                "type": "message",
                "role": role,
                "content": [{"type": "input_text" if role == "user" else "output_text", "text": text}],
            },
        }
    if turn is not None:
        yield event("task_complete", turn_id=turn, last_agent_message=last_answer)


def save_codex(session, snapshot, changes):
    revision, messages = storage.load_codex(session)
    if revision != snapshot:
        raise ValueError(tr("会话在编辑期间发生了变化。请刷新并重新编辑。"))
    cwd = workdir(session)
    ident = str(uuid4())
    stem = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
    with tempfile.TemporaryDirectory(prefix="codex-editor-") as directory:
        path = Path(directory) / f"rollout-{stem}-{ident}.jsonl"
        with path.open("wb") as destination:
            for row in codex_seed(session, ident, messages, changes):
                destination.write(storage.json_line(row) + b"\n")
        with CodexClient(cwd) as client:
            result = client.call("thread/fork", {
                "threadId": ident, "path": str(path), "cwd": str(cwd),
                "excludeTurns": True,
            })
            new = result["thread"]["id"]
            client.call("thread/name/set", {"threadId": new, "name": session.title + tr(" · 已编辑")})
    return new


def workdir(session):
    path = Path(session.cwd) if session and session.cwd else storage.HOME / "Documents"
    return path if path.is_dir() else storage.HOME


def open_native(platform, session=None, new=False):
    ident = str(UUID(session.id)) if session and not new else None
    cwd = workdir(session)
    env = os.environ.copy()
    if platform == "Codex":
        managed_home = settings.codex_home()
        if managed_home == settings.HOME / ".codex" and not settings.get(platform, "executable"):
            uri = "codex://threads/" + (ident or "new?" + urlencode({"path": str(cwd)}))
            try:
                os.startfile(uri)
                return
            except OSError:
                pass
        args = ["resume", ident] if ident else []
        env["CODEX_HOME"] = str(managed_home)
    elif platform == "AGY App":
        subprocess.run(
            [str(POWERSHELL), "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
             str(Path(__file__).with_name("agy-app.ps1")), str(executable(platform)),
             "new" if new else "picker"],
            check=True, timeout=20, creationflags=subprocess.CREATE_NO_WINDOW,
        )
        return
    elif platform == "AGY CLI":
        args = ["--conversation", ident] if ident else []
    else:
        args = ["--resume", ident] if ident else []
        env["CLAUDE_CONFIG_DIR"] = str(session.claude_root if session and session.claude_root else settings.claude_home())

    subprocess.Popen(command_line(executable(platform), args), cwd=cwd, env=env,
                     creationflags=subprocess.CREATE_NEW_CONSOLE)
