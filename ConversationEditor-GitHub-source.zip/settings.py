"""Per-user Windows configuration. No transcripts or credentials are stored here."""
import json
import os
from pathlib import Path
import tempfile

HOME = Path.home()
LOCAL = Path(os.environ.get("LOCALAPPDATA") or HOME / "AppData/Local")
ROAMING = Path(os.environ.get("APPDATA") or HOME / "AppData/Roaming")
SETTINGS_DIR = LOCAL / "ConversationEditor"
CONFIG = SETTINGS_DIR / "settings.json"
BACKUPS = SETTINGS_DIR / "Backups"

AGY_DIRS = {"AGY CLI": "antigravity-cli", "AGY App": "antigravity"}
PLATFORMS = (*AGY_DIRS, "Claude Code", "Codex")


def read():
    if not CONFIG.is_file():
        return {}
    with CONFIG.open(encoding="utf-8") as source:
        data = json.load(source)
    if not isinstance(data, dict):
        raise ValueError("settings.json must contain a JSON object.")
    return data


def get(platform, key):
    value = read().get(platform, {}).get(key)
    return Path(value) if value else None


def claude_home():
    return get("Claude Code", "data") or Path(os.environ.get("CLAUDE_CONFIG_DIR") or HOME / ".claude")


def codex_home():
    return get("Codex", "data") or Path(os.environ.get("CODEX_HOME") or HOME / ".codex")


def agy_home(platform):
    return get(platform, "data") or HOME / ".gemini" / AGY_DIRS[platform]


def data_home(platform):
    if platform == "Claude Code":
        return claude_home()
    if platform == "Codex":
        return codex_home()
    return agy_home(platform)


def save(platform, data, executable):
    data = data.strip()
    executable = executable.strip()
    if data and not Path(data).expanduser().is_dir():
        raise ValueError("The conversation data directory does not exist.")
    if executable:
        path = Path(executable).expanduser()
        if not path.is_file() or path.suffix.lower() not in {".exe", ".cmd", ".bat"}:
            raise ValueError("Choose an existing .exe, .cmd or .bat file.")
    config = read()
    config[platform] = {
        "data": str(Path(data).expanduser().resolve()) if data else "",
        "executable": str(Path(executable).expanduser().resolve()) if executable else "",
    }
    SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=SETTINGS_DIR, mode="w", encoding="utf-8", delete=False) as stream:
        staged = Path(stream.name)
        json.dump(config, stream, indent=2, ensure_ascii=False)
    try:
        staged.replace(CONFIG)
    finally:
        staged.unlink(missing_ok=True)
