"""Local transcript discovery and content updates."""
import contextlib
import dataclasses
import datetime as dt
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import tempfile
from urllib.parse import unquote, urlsplit

import settings
from language import tr

HOME = settings.HOME
AGY_ROOTS = settings.AGY_DIRS
BACKUPS = settings.BACKUPS


@dataclasses.dataclass(frozen=True)
class Session:
    platform: str
    id: str
    path: Path
    title: str
    cwd: str = ""
    claude_root: Path | None = None


@dataclasses.dataclass(frozen=True)
class Message:
    key: tuple
    role: str
    text: str


def read_db(path):
    return contextlib.closing(sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True))


def read_json(path, default):
    if not path.is_file():
        return default
    return json.loads(path.read_text(encoding="utf-8-sig"))


def ordered(paths):
    return sorted(paths, key=lambda p: p.stat().st_mtime_ns, reverse=True)


def find_sessions(platform):
    if platform in AGY_ROOTS:
        root = settings.agy_home(platform)
        cache_path = root / "cache/conversation_metadata.json"
        cache = read_json(cache_path, {}).get("conversations", {})
        if platform == "AGY App" and not cache:
            cache = read_json(settings.agy_home("AGY CLI") / "cache/conversation_metadata.json", {}).get("conversations", {})
        for path in ordered((root / "conversations").glob("*.db")):
            summary = cache.get(path.stem, {}).get("summary", {})
            workspaces = summary.get("WorkspaceURIs") or []
            uri = urlsplit(workspaces[0]) if isinstance(workspaces, list) and workspaces else None
            cwd = unquote(uri.path).lstrip("/") if uri and uri.scheme == "file" else ""
            yield Session(platform, path.stem, path, summary.get("Title") or path.stem, cwd)
    elif platform == "Claude Code":
        files = {path: root for root in (settings.claude_home(),) for path in (root / "projects").glob("*/*.jsonl")}
        for path in ordered(files):
            title, cwd = path.stem, ""
            with path.open(encoding="utf-8") as source:
                for line in source:
                    if not line.strip():
                        continue
                    try:
                        record = json.loads(line)
                    except json.JSONDecodeError:
                        break
                    cwd = record.get("cwd") or cwd
                    content = record.get("message", {}).get("content")
                    if record.get("type") == "user" and not record.get("isMeta"):
                        if isinstance(content, list):
                            content = next((c.get("text") for c in content if c.get("type") == "text"), "")
                        if isinstance(content, str) and content.strip():
                            title = content.strip().splitlines()[0]
                            break
            yield Session(platform, path.stem, path, title, cwd, files[path])
    elif platform == "Codex":
        databases = ordered(settings.codex_home().glob("state_*.sqlite"))
        if databases:
            with read_db(databases[0]) as conn:
                rows = conn.execute(
                    "SELECT id, rollout_path, title, cwd FROM threads "
                    "WHERE archived = 0 ORDER BY updated_at DESC"
                ).fetchall()
            for ident, filename, title, cwd in rows:
                path = Path(filename)
                if path.is_file():
                    yield Session(platform, ident, path, title or ident, cwd or "")


# AGY stores message text inside length-delimited protobuf fields. Preserve
# original bytes for every field outside the documented-in-code text paths.
def varint(data, offset):
    value = 0
    for shift in range(0, 70, 7):
        if offset >= len(data):
            break
        byte = data[offset]
        offset += 1
        value |= (byte & 127) << shift
        if byte < 128:
            return value, offset
    raise ValueError(tr("无效的 Antigravity 消息编码。"))


def encode_varint(value):
    result = bytearray()
    while value >= 128:
        result.append((value & 127) | 128)
        value >>= 7
    result.append(value)
    return bytes(result)


def wire_fields(data):
    offset = 0
    while offset < len(data):
        start = offset
        tag, offset = varint(data, offset)
        field, wire = divmod(tag, 8)
        if not field:
            raise ValueError(tr("无效的 Antigravity 字段。"))
        if wire == 0:
            value, offset = varint(data, offset)
        elif wire in (1, 2, 5):
            if wire == 2:
                length, offset = varint(data, offset)
            else:
                length = {1: 8, 5: 4}[wire]
            end = offset + length
            if end > len(data):
                raise ValueError(tr("Antigravity 消息不完整。"))
            value, offset = data[offset:end], end
        else:
            raise ValueError(tr("此 Antigravity 消息使用了不同的编码。"))
        yield field, wire, value, data[start:offset]


def wire_at(data, path):
    for part in path:
        values = [value for field, wire, value, _ in wire_fields(data) if field == part and wire == 2]
        if len(values) != 1:
            return None
        data = values[0]
    return data


def wire_replace(data, path, new):
    result = bytearray()
    for field, wire, value, original in wire_fields(data):
        if field == path[0] and wire == 2:
            value = wire_replace(value, path[1:], new) if len(path) > 1 else new
            result += encode_varint(field * 8 + 2) + encode_varint(len(value)) + value
        else:
            result += original
    return bytes(result)


AGY_FIELDS = {
    14: ("user", (19, 2), ((19, 3, 1),)),
    15: ("assistant", (20, 1), ((20, 8),)),
}
AGY_QUERY = "SELECT idx, step_type, step_payload FROM steps WHERE step_format = 0 AND step_type IN (14, 15) ORDER BY idx"


def agy_parts(kind, payload):
    role, primary, copies = AGY_FIELDS[kind]
    value = wire_at(payload, primary)
    if not value:
        return None
    return role, value.decode("utf-8"), (primary, *(p for p in copies if wire_at(payload, p) == value))


def backup_path(path):
    BACKUPS.mkdir(parents=True, exist_ok=True)
    now = dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    return BACKUPS / (now + "-" + path.name)


def save_agy(session, snapshot, changes):
    # Closing the corresponding client releases its in-memory conversation.
    ensure_closed(session.platform)
    with read_db(session.path) as source, contextlib.closing(sqlite3.connect(session.path, timeout=2)) as conn:
        with conn:
            conn.execute("BEGIN IMMEDIATE")
            rows = conn.execute(AGY_QUERY).fetchall()
            if agy_revision(rows) != snapshot:
                raise ValueError(tr("会话在编辑期间发生了变化。请刷新并重新编辑。"))
            with contextlib.closing(sqlite3.connect(backup_path(session.path))) as backup:
                source.backup(backup)
            for idx, kind, payload in rows:
                if (idx,) in changes:
                    _, _, fields = agy_parts(kind, payload)
                    for field in fields:
                        payload = wire_replace(payload, field, changes[idx,].encode("utf-8"))
                    conn.execute("UPDATE steps SET step_payload = ? WHERE idx = ?", (payload, idx))
    return session.id


def agy_revision(rows):
    digest = hashlib.sha256()
    for idx, kind, payload in rows:
        digest.update(f"{idx}:{kind}:{len(payload)}:".encode())
        digest.update(payload)
    return digest.hexdigest()


def ensure_closed(platform):
    images = {
        "AGY CLI": ("agy.exe",),
        "AGY App": ("antigravity.exe", "language_server.exe"),
        "Claude Code": ("claude.exe",),
    }[platform]
    configured = settings.get(platform, "executable")
    if configured and configured.suffix.lower() == ".exe":
        images = (*images, configured.name.lower())
    running = subprocess.check_output(
        ["tasklist.exe", "/FO", "CSV", "/NH"], creationflags=subprocess.CREATE_NO_WINDOW,
    ).lower()
    if any(b'"' + image.encode() + b'"' in running for image in images):
        raise ValueError(tr("请完全退出 {platform}（AGY App 也要退出系统托盘），再保存并重新打开会话。", platform=platform))


def json_messages(platform, records):
    for row, record in enumerate(records):
        if platform == "Claude Code":
            role = record.get("type")
            if role not in {"user", "assistant"} or record.get("isMeta") or record.get("isSidechain"):
                continue
            prefix = ("message", "content")
            body = record.get("message", {}).get("content")
            if isinstance(body, str) and body:
                yield Message((row, *prefix), role, body)
        else:
            payload = record.get("payload", {})
            role = payload.get("role")
            if record.get("type") != "response_item" or payload.get("type") != "message" or role not in {"user", "assistant"}:
                continue
            prefix = ("payload", "content")
            body = payload.get("content")
        if not isinstance(body, list):
            continue
        for index, part in enumerate(body):
            if platform == "Codex" and role == "user":
                metadata = payload.get("internal_chat_message_metadata_passthrough", {})
                kinds = metadata.get("content_item_kinds") or []
                if index < len(kinds) and kinds[index] != "user.text":
                    continue
            if part.get("type") in {"text", "input_text", "output_text"} and part.get("text"):
                yield Message((row, *prefix, index, "text"), role, part["text"])


def load(session):
    if session.platform == "Codex":
        return load_codex(session)
    if session.platform in AGY_ROOTS:
        messages = []
        with read_db(session.path) as conn:
            rows = conn.execute(AGY_QUERY).fetchall()
        for idx, kind, payload in rows:
            parts = agy_parts(kind, payload)
            if parts:
                role, value, _ = parts
                messages.append(Message((idx,), role, value))
        return agy_revision(rows), messages
    raw = session.path.read_bytes()
    records = [json.loads(line) for line in raw.splitlines() if line.strip()]
    return hashlib.sha256(raw).hexdigest(), list(json_messages(session.platform, records))


def json_line(record):
    return json.dumps(record, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def rewrite_json(session, snapshot, changes):
    raw = session.path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != snapshot:
        raise ValueError(tr("会话在编辑期间发生了变化。请刷新并重新编辑。"))
    lines = [line for line in raw.splitlines() if line.strip()]
    records = [json.loads(line) for line in lines]
    touched = set()
    for key, text in changes.items():
        row, *path = key
        node = records[row]
        for part in path[:-1]:
            node = node[part]
        node[path[-1]] = text
        touched.add(row)

    for row in touched:
        lines[row] = json_line(records[row])
    return raw, b"\n".join(lines) + b"\n"


def save_claude(session, snapshot, changes):
    ensure_closed(session.platform)
    raw, edited = rewrite_json(session, snapshot, changes)
    backup_path(session.path).write_bytes(raw)
    with tempfile.NamedTemporaryFile(dir=session.path.parent, delete=False) as temp:
        path = Path(temp.name)
        temp.write(edited)
    try:
        if session.path.read_bytes() != raw:
            raise ValueError(tr("会话在保存期间发生了变化，请刷新。"))
        path.replace(session.path)
    finally:
        path.unlink(missing_ok=True)
    return session.id


def codex_rollouts(path, cutoff=None, seen=()):
    """Yield the files and byte limits needed to reconstruct a Codex transcript."""
    path = path.resolve()
    if path in seen:
        raise ValueError(tr("Codex 会话的历史文件存在循环引用。"))
    with path.open("rb") as source:
        meta = json.loads(source.readline())
    payload = meta["payload"]
    parent = payload.get("history_base")
    if parent:
        ident = parent["thread_id"]
        limit = parent["end_byte_offset"]
        end_ordinal = parent["end_ordinal_exclusive"]
        candidates = (
            candidate
            for root in (settings.codex_home() / "sessions", settings.codex_home() / "archived_sessions")
            for candidate in root.rglob(f"rollout-*{ident}*.jsonl")
            if candidate.resolve() not in (*seen, path)
            and candidate.stat().st_size >= limit
        )
        for candidate in candidates:
            with candidate.open("rb") as source:
                try:
                    source.seek(limit - 1)
                    if source.read(1) != b"\n":
                        continue
                    # Verify the cutoff belongs to this physical rollout.
                    next_line = source.readline()
                    if next_line and json.loads(next_line).get("ordinal") != end_ordinal:
                        continue
                except (OSError, ValueError, AttributeError):
                    continue
                yield from codex_rollouts(candidate, limit, (*seen, path))
                break
        else:
            raise ValueError(tr("找不到 Codex 会话的上一段历史，无法完整载入。"))
    yield path, cutoff


def load_codex(session):
    revision = hashlib.sha256()
    messages = []
    row = 0
    for path, limit in codex_rollouts(session.path):
        with path.open("rb") as source:
            offset = 0
            for line in source:
                offset += len(line)
                if limit is not None and offset > limit:
                    break
                revision.update(line)
                if not line.strip():
                    continue
                record = json.loads(line)
                for item in json_messages("Codex", [record]):
                    messages.append(Message((row, *item.key[1:]), item.role, item.text))
                row += 1
    return revision.hexdigest(), messages
