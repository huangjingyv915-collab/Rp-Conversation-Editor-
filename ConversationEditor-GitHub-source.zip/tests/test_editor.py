"""Synthetic transcript tests. Never open real user profiles."""
from contextlib import closing
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch
from uuid import uuid4

import native
import settings
import storage


class TranscriptTests(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory(prefix="conversation-editor-")
        self.addCleanup(folder.cleanup)
        self.base = Path(folder.name)
        settings_dir = self.base / "app"
        for target, value in (
            ("settings.SETTINGS_DIR", settings_dir),
            ("settings.CONFIG", settings_dir / "settings.json"),
            ("storage.BACKUPS", settings_dir / "Backups"),
            ("storage.ensure_closed", lambda _: None),
        ):
            mock = patch(target, value)
            mock.start()
            self.addCleanup(mock.stop)

    def test_custom_profile_and_reset(self):
        custom = self.base / "会话"
        custom.mkdir()
        exe = self.base / "tool.exe"
        exe.touch()
        settings.save("Claude Code", str(custom), str(exe))
        self.assertEqual(settings.claude_home(), custom)
        self.assertEqual(native.executable("Claude Code"), exe)
        settings.save("Claude Code", "", "")
        self.assertIsNone(settings.get("Claude Code", "data"))
        self.assertIsNone(settings.get("Claude Code", "executable"))

    def test_claude_round_trip_and_backup(self):
        ident = str(uuid4())
        project = self.base / "projects" / "project"
        project.mkdir(parents=True)
        path = project / (ident + ".jsonl")
        user = {"type": "user", "message": {"content": "first"}}
        answer = {"type": "assistant", "message": {"content": [
            {"type": "text", "text": "second"}, {"type": "tool_use", "name": "demo"},
        ]}}
        path.write_bytes(b"\n".join(map(storage.json_line, [user, answer])) + b"\n")
        original = path.read_bytes()
        with patch.object(settings, "claude_home", return_value=self.base):
            (session,) = storage.find_sessions("Claude Code")
        revision, messages = storage.load(session)
        changes = {m.key: f"{m.text} 中文" for m in messages}
        storage.save_claude(session, revision, changes)
        self.assertEqual([m.text for m in storage.load(session)[1]], ["first 中文", "second 中文"])
        (backup,) = storage.BACKUPS.glob("*.jsonl")
        self.assertEqual(backup.read_bytes(), original)
        self.assertIn(b'"tool_use"', path.read_bytes())
        with self.assertRaises(ValueError):
            storage.save_claude(session, revision, changes)

    def test_antigravity_updates_both_text_fields_and_preserves_other_bytes(self):
        def field(number, value):
            return storage.encode_varint((number << 3) | 2) + storage.encode_varint(len(value)) + value

        for platform in settings.AGY_DIRS:
            with self.subTest(platform=platform):
                ident = str(uuid4())
                path = self.base / (ident + ".db")
                suffix = field(21, b"keep")
                prompt = field(19, field(2, b"first") + field(3, field(1, b"first")) + suffix)
                response = field(20, field(1, b"second") + field(8, b"second") + suffix)
                with closing(sqlite3.connect(path)) as db, db:
                    db.execute("CREATE TABLE steps (idx INTEGER PRIMARY KEY, step_type INTEGER, step_format INTEGER, step_payload BLOB)")
                    db.executemany("INSERT INTO steps VALUES (?, ?, 0, ?)", [(0, 14, prompt), (1, 15, response)])
                session = storage.Session(platform, ident, path, "Example")
                revision, _ = storage.load(session)
                store = {(0,): "修改的问题", (1,): "修改的回答"}
                storage.save_agy(session, revision, store)
                self.assertEqual([m.text for m in storage.load(session)[1]], list(store.values()))
                with storage.read_db(path) as db:
                    for idx, kind, payload in db.execute(storage.AGY_QUERY):
                        role, primary, mirrors = storage.AGY_FIELDS[kind]
                        for address in (primary, *mirrors):
                            self.assertEqual(storage.wire_at(payload, address), store[idx,].encode())
                        self.assertTrue(storage.wire_at(payload, (primary[0],)).endswith(suffix))
                    self.assertEqual(db.execute("PRAGMA integrity_check").fetchone(), ("ok",))

    def test_codex_reads_continuation_and_seeds_both_roles(self):
        folder = self.base / "sessions"
        folder.mkdir()
        ident, continuation = str(uuid4()), str(uuid4())
        parent = folder / f"rollout-2026-01-01T00-00-00-{ident}.jsonl"
        path = folder / f"rollout-2026-01-01T01-00-00-{ident}_{continuation}.jsonl"

        def meta(data):
            return {"timestamp": "2026-01-01T00:00:00Z", "type": "session_meta", "payload": {"id": ident, **data}}

        def message(role, text):
            return {"type": "response_item", "payload": {
                "type": "message", "role": role,
                "content": [{"type": "input_text" if role == "user" else "output_text", "text": text}],
            }}

        def lines(*rows):
            return b"\n".join(map(storage.json_line, rows)) + b"\n"

        parent.write_bytes(lines(meta({}), message("user", "original prompt")))
        base = {"thread_id": ident, "end_byte_offset": parent.stat().st_size, "end_ordinal_exclusive": 2}
        path.write_bytes(lines(meta({"history_base": base}), message("assistant", "original reply")))
        session = storage.Session("Codex", ident, path, "Example")
        with patch.object(settings, "codex_home", return_value=self.base):
            _, messages = storage.load(session)
        self.assertEqual([m.role for m in messages], ["user", "assistant"])
        modified = {m.key: m.text.replace("original", "edited") for m in messages}
        seed = list(native.codex_seed(session, str(uuid4()), messages, modified))
        self.assertNotIn("history_base", seed[0]["payload"])
        self.assertEqual([m.text for m in storage.json_messages("Codex", seed)], ["edited prompt", "edited reply"])
        self.assertIn("user_message", [x["payload"].get("type") for x in seed])
        self.assertIn("agent_message", [x["payload"].get("type") for x in seed])

    def test_npm_shim_receives_each_argument(self):
        launcher = self.base / "fake launcher.cmd"
        launcher.write_text("@echo off\r\necho %~1 %~2\r\n", encoding="ascii")
        result = native.subprocess.check_output(native.command_line(launcher, ["resume", "sample"]), text=True)
        self.assertEqual(result.strip(), "resume sample")


if __name__ == "__main__":
    unittest.main()
